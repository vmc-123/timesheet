import { element } from 'protractor';
import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

export interface ITimesheet {
  date:string,
  project:string,
  taskTitle:string,
  time:string,
  id?:number,
  isEditable:boolean
}
const timesheetData: ITimesheet[] = [
  {date: "15/03/2021", project: 'MB', taskTitle: 'BI Structure', time: '04:00',isEditable:false},
  {date: "15/03/2021", project: 'MB', taskTitle: 'ETL Installation', time: '04:00',isEditable:false},
  {date: "16/03/2021", project: 'MB', taskTitle: 'Basic Transformation', time: '08:00',isEditable:false},
  {date: "17/03/2021", project: 'MB', taskTitle: 'BI Structure', time: '08:00',isEditable:false},
  {date: "18/03/2021", project: 'MB', taskTitle: 'BI Structure', time: '08:00',isEditable:false},
];
@Component({
  selector: 'app-timesheet',
  templateUrl: './timesheet.component.html',
  styleUrls: ['./timesheet.component.css']
})
export class TimesheetComponent implements OnInit {

  
  displayedColumns: string[] = ['Date', 'Project', 'Task Title', 'Time', 'Action'];
  dataSource = new MatTableDataSource(timesheetData);
  projectArr: any[] = [
    {value: 'MB', viewValue: 'MB'},
    {value: 'project1', viewValue: 'Project 1'},
    {value: 'project2', viewValue: 'Project 2'},
    {value: 'project3', viewValue: 'Project 3'}
  ];
  constructor() { }

  ngOnInit(): void {
  }

  addNewRow(id){
    console.log(id);
    let temp={};
    let row:ITimesheet = Object.assign(temp,timesheetData[id]);
    timesheetData.splice(id+1,0,{date: row.date, project: '', taskTitle: '', time: '',isEditable:false});
    this.dataSource = new MatTableDataSource(timesheetData);
  }
  cellClicked(element,_type){
    console.log(element);
    for(let i=0;i<timesheetData.length;i++){
      timesheetData[i].isEditable=false;
    }
    element.isEditable = true;
  }
  saveUpdateData(){
    for(let i=0;i<timesheetData.length;i++){
      timesheetData[i].isEditable=false;
    }
  }
  saveData(){
    console.log(timesheetData);
  }
}
