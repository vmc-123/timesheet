import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserIterationComponent } from './user-iteration.component';

describe('UserIterationComponent', () => {
  let component: UserIterationComponent;
  let fixture: ComponentFixture<UserIterationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserIterationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserIterationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
